//
// Created by wzk on 2020/9/29.
//

#ifndef COMPILER_GRAMMARRESULTS_H
#define COMPILER_GRAMMARRESULTS_H


class GrammarResults {

};


#endif //COMPILER_GRAMMARRESULTS_H
