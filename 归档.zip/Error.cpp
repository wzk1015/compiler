//
// Created by wzk on 2020/10/1.
//

#include "Error.h"

vector<Error> Errors::errors;