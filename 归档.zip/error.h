#include <utility>

//
// Created by wzk on 2020/9/22.
//

#ifndef COMPILER_ERROR_H
#define COMPILER_ERROR_H

#define NOTFOUND "NOT FOUND"
#define INVALID "NOT VALID"

class Error{
public:
    string msg;
    int line{};
    int column{};

    explicit Error(string s): msg(move(s)) {};
    Error(string s, int ln, int col) : msg(std::move(s)), line(ln), column(col) {};
};

class ErrorException : public exception {
    vector<Error> errors;
    const char *what() const noexcept override {
        //return ("Error in line " + to_string(ln) + ", column " + to_string(col) + ": " + move(s)).c_str();
    }
};

#define E_UNEXPECTED_CHAR 1
#define E_UNKNOWN_CHAR 2
#define E_UNEXPECTED_EOF 3


#endif