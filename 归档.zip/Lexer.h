//
// Created by wzk on 2020/9/22.
//

#ifndef COMPILER_LEXER_H
#define COMPILER_LEXER_H
#include <iostream>
#include <fstream>
#include <vector>
#include "LexResults.h"
#include "error.h"

using namespace std;

class Lexer {
public:
    char ch{};
    string token;
    string symbol;
    string source;
    int pos = 0;
    int line_num = 1;
    int col_num = 1;
    bool save_to_file = false;
    int int_v = -1;
    int num_tokens = 0;
    vector<Error> errors;

    int read_char();
    vector<LexResults> analyze(const char *, const char *);
    LexResults get_token();
    void retract();
    static string special(char);
    static string reserved(string);
    explicit Lexer(bool save_to_file): save_to_file(save_to_file) {};
};


#endif
