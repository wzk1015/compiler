//
// Created by wzk on 2020/10/24.
//

#ifndef COMPILER_UTILS_H
#define COMPILER_UTILS_H

#include <iostream>

using namespace std;

string lower(string);

bool is_2_power(int);

bool begins_num(string);

bool num_or_char(string);

void panic(const string&);

#endif //COMPILER_UTILS_H
