//
// Created by wzk on 2020/10/24.
//

#ifndef COMPILER_UTILS_H
#define COMPILER_UTILS_H

#include <iostream>

using namespace std;

string lower(string wd);


#endif //COMPILER_UTILS_H
