//
// Created by wzk on 2020/10/1.
//

#ifndef COMPILER_SYMTABLEITEM_H
#define COMPILER_SYMTABLEITEM_H

#include <iostream>
#include <utility>

using namespace std;

class SymTableItem {
public:

    //function
    bool has_return{};
};


#endif //COMPILER_SYMTABLEITEM_H
