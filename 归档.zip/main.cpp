#include "Lexer.h"

using namespace std;


int main() {
    vector<Error> errors;

    Lexer lexer = Lexer(true);
    vector<LexResults> lex_results = lexer.analyze("testfile.txt", "output.txt");

    errors.insert(errors.end(), lexer.errors.begin(), lexer.errors.end());

    return 0;
}
