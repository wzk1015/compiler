#include <iostream>
#include "TokenAnalyze.h"

using namespace std;



int main() {
    TokenAnalyze ta = TokenAnalyze();
    ta.analyze("testfile.txt", "output.txt");
    return 0;
}
