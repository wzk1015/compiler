//
// Created by wzk on 2020/9/22.
//

#ifndef TOKEN_ANALYZE_TOKENANALYZE_H
#define TOKEN_ANALYZE_TOKENANALYZE_H
#include <iostream>
#include <fstream>
using namespace std;

class TokenAnalyze {
private:
    char ch;
    string token;
    int num;
    string symbol;
    string source;
    int pos = 0;
    ofstream out;

public:
    int read(const char *, const char *);
    int read_char();
    int analyze(const char *, const char *);
    int get_token();
    int output();
    void retract();
    static void error();
    string special(char);
    string reserver(string);


};


#endif //TOKEN_ANALYZE_TOKENANALYZE_H
