//
// Created by wzk on 2020/9/22.
//

#include "TokenAnalyze.h"
#include <map>
#include <sstream>

#define NOTFOUND "NOT FOUND"


string lower(string wd) {
    string s;
    int len = wd.size();
    for (int i = 0; i < len; i++) {
        if (wd[i] >= 'A' && wd[i] <= 'Z') {
            s += (char) (wd[i] + 'a' - 'A');
        } else {
            s += wd[i];
        }
    }
    return s;
}


int TokenAnalyze::get_token() {
    token.clear();
    int d = source.length();
    while ((ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r') && pos < source.length())
        read_char();
    if ((ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r')) {
        return 0;
    }
    if (isalpha(ch) || ch == '_') {
        while (isalnum(ch) || ch == '_') {
            token += ch;
            read_char();
        }
        retract();
        string reserver_value = reserver(token);
        symbol = (reserver_value == NOTFOUND) ? "IDENFR" : reserver_value;
    } else if (isdigit(ch)) {
        while (isdigit(ch)) {
            token += ch;
            read_char();
        }
        retract();
        symbol = "INTCON";
    } else if (ch == '\'') {
        read_char();
        token = ch;
        symbol = "CHARCON";
        read_char();
        if (ch != '\'') {
            error();
        }
    } else if (ch == '\"') {
        while (true) {
            read_char();
            if (ch == '\"') {
                break;
            }
            token += ch;
        }
        symbol = "STRCON";
    } else if (special(ch) != NOTFOUND) {
        symbol = special(ch);
    } else if (ch == '!') {
        read_char();
        if (ch != '=') {
            error();
        }
        token = "!=";
        symbol = "NEQ";
    } else if (ch == '=') {
        read_char();
        if (ch == '=') {
            token = "==";
            symbol = "EQL";
        } else {
            token = "=";
            symbol = "ASSIGN";
            retract();
        }
    } else if (ch == '<') {
        read_char();
        if (ch == '=') {
            token = "<=";
            symbol = "LEQ";
        } else {
            token = "<";
            symbol = "LSS";
            retract();
        }
    } else if (ch == '>') {
        read_char();
        if (ch == '=') {
            token = ">=";
            symbol = "GEQ";
        } else {
            token = ">";
            symbol = "GRE";
            retract();
        }
    } else {
        error();
    }

    out << symbol << " " << token << endl;
    return 0;
}

int TokenAnalyze::analyze(const char *in_path, const char *out_path) {
    read(in_path, out_path);
    while (pos < source.length() - 1) {
        read_char();
        get_token();
    }
    out.close();
    cout << "token analyze done successfully." << endl;
    return 0;
}

int TokenAnalyze::read_char() {
    if (pos >= source.length()) {
        error();
    }
    ch = source[pos];
    pos++;
    return 0;
}

void TokenAnalyze::retract() {
    pos--;
    //TODO
}

void TokenAnalyze::error() {
//    throw runtime_error("token analyze error");
    //TODO
}

int TokenAnalyze::read(const char *in_path, const char *out_path) {
    ifstream stream;
    stringstream buffer;
    stream.open(in_path);
    buffer << stream.rdbuf();
    source = buffer.str();
    stream.close();

    out.open(out_path);
    return 0;
}

string TokenAnalyze::reserver(string tk) {
    map<string, string> reserves = {
            {"const",   "CONSTTK"},
            {"int",     "INTTK"},
            {"char",    "CHARTK"},
            {"void",    "VOIDTK"},
            {"main",    "MAINTK"},
            {"if",      "IFTK"},
            {"else",    "ELSETK"},
            {"switch",  "SWITCHTK"},
            {"case",    "CASETK"},
            {"default", "DEFAULTTK"},
            {"while",   "WHILETK"},
            {"for",     "FORTK"},
            {"scanf",   "SCANFTK"},
            {"printf",  "PRINTFTK"},
            {"return",  "RETURNTK"},
    };
    auto iter = reserves.find(lower(std::move(tk)));
    if (iter != reserves.end()) {
        return iter->second;
    }
    return NOTFOUND;
}

string TokenAnalyze::special(char tk) {
    map<char, string> specials = {
            {'+', "PLUS"},
            {'-', "MINU"},
            {'*', "MULT"},
            {'/', "DIV"},
            {':', "COLON"},
            {';', "SEMICN"},
            {',', "COMMA"},
            {'(', "LPARENT"},
            {')', "RPARENT"},
            {'[', "LBRACK"},
            {']', "RBRACK"},
            {'{', "LBRACE"},
            {'}', "RBRACE"}
    };
    auto iter = specials.find(tk);
    if (iter != specials.end()) {
        token = iter->first;
        return iter->second;
    }
    return NOTFOUND;
}


